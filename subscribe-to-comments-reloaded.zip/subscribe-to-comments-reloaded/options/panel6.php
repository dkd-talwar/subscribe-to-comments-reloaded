<?php
// Avoid direct access to this piece of code
if ( ! function_exists( 'is_admin' ) || ! is_admin() )
{
	header( 'Location: /' );
	exit;
}
?>
<div class="postbox">
	<table class="table table-hover">
		<thead>
			<tr>
				<th>test</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>test</td>
			</tr>
		</tbody>
	</table>
</div>


